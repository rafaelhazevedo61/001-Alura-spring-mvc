package br.com.alura.mvc.mudi.model;

public enum StatusPedido {

	AGUARDANDO, APROVADO, ENTREGUE;
	
}
